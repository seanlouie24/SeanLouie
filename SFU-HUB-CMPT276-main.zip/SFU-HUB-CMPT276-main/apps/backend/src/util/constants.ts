export const DAY = 86400;
export const DAYS_IN_WEEK = 7;
export const msToSeconds = (ms: number) => Math.round(ms / 1000);
export const DAYS: ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'] = [
    'sunday',
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
];
